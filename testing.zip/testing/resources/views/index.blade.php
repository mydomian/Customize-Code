<?php
  if (isset($_POST["submit"])) {
    $username = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $message = $_POST["message"];

    $to = $email;
    $subject = $message;

    $message = "Name: {$username} Email: {$email} Phone: {$phone}  Message: " . $message;

    // Always set content-type when sending HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

    // More headers
    $headers .= 'From: bravecoderofficial@gmail.com';

    $mail = mail($to,$subject,$message,$headers);

    if ($mail) {
      echo "<script>alert('Mail Send.');</script>";
    }else {
      echo "<script>alert('Mail Not Send.');</script>";
    }
  }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contact Form</title>
    <!-- <link rel="stylesheet" href="style.css" /> -->
    <link rel="stylesheet" href="{{asset('css/style.css')}}">
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
    <style>
::placeholder {
  color: white;
}
</style>
      <script src="https://code.jquery.com/jquery-3.3.1.min.js"
      ></script>
      <script>
          $(document).ready(function() {
              var max_fields      = 2; //maximum input boxes allowed
              var wrapper         = $(".input_fields_wrap"); //Fields wrapper
              var add_button      = $(".add_field_button"); //Add button ID

              var x = 1; //initlal text box count
              $(add_button).click(function(e){ //on add input button click
                  e.preventDefault();
                  if(x < max_fields){ //max input box allowed

                      //text box increment
                      $(wrapper).append('<div><div class="test"><input type="text" readonly class="form" style="margin-top:10px" name="mytext[]"/></div><a href="#" class="checking"><input style="margin-top: 13px;" type="checkbox" name="mandatory" value="Mandatory"><label for="html" style="margin-top: 33px;">Mandatory</label></a><span style="color:red;"" class="error_show"></span><a href="#" style="margin-left: 90px;font-size:12px;text-decoration: none;color: red" class="remove_field">Remove</a></div>'); //add input box
                      x++;
                  }
              });

              //Check Validate
              $(wrapper).on("click",".checking", function(e){ //user click on remove text
                  e.preventDefault();

                        if("input[input='checkbox'] :checked".length>0){
                            $(".test").html('<input type="text" class="form" style="margin-top:10px" name="mytext[]"/>')
                        }else{
                            $(".test").html('<input type="text" readonly class="form" style="margin-top:10px" name="mytext[]"/>')
                        }
              });
              $(wrapper).on("click",".remove_field", function(e){ //user click on remove text

                  e.preventDefault();
                  $(this).parent('div').remove();
                  x--;
              });





          });

      </script>
  </head>
  <body>
    <div class="container">
      <span class="big-circle"></span>
      <img src="img/shape.png" class="square" alt="" />
      <div class="form">
        <div class="contact-info">
          <h3 class="title">Let's get in touch</h3>
          <p class="text">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Saepe
            dolorum adipisci recusandae praesentium dicta!
          </p>

          <div class="info">
            <div class="information">
              <img src="img/location.png" class="icon" alt="" />
              <p>92 Cherry Drive Uniondale, NY 11553</p>
            </div>
            <div class="information">
              <img src="img/email.png" class="icon" alt="" />
              <p>lorem@ipsum.com</p>
            </div>
            <div class="information">
              <img src="img/phone.png" class="icon" alt="" />
              <p>123-456-789</p>
            </div>
          </div>

          <div class="social-media">
            <p>Connect with us :</p>
            <div class="social-icons">
              <a href="#">
                <i class="fab fa-facebook-f"></i>
              </a>
              <a href="#">
                <i class="fab fa-twitter"></i>
              </a>
              <a href="#">
                <i class="fab fa-instagram"></i>
              </a>
              <a href="#">
                <i class="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>
        </div>

        <div class="contact-form">
          <span class="circle one"></span>
          <span class="circle two"></span>

          <form>
{{--              {{url('/submiting')}}--}}
{{--          @csrf--}}
          <h3 class="title">Contact us</h3>
            <div class="input-container">
               {{-- Edit Section--}}
                <div class="input_fields_wrap">
                    <text class="add_field_button" title="Enter Your Name">Name</text>
                    <div>
                        <input type="text" hidden name="mytext[]">
                    </div>

                </div>


                <!-- <span class="checkmark" ></span> -->
              </div>
              <!-- <label for="">Username</label> -->
            <input type="submit" name="submit" value="Send" class="btn" />
          </form>
        </div>
      </div>
    </div>

    <script src="app.js"></script>

  </body>
</html>
