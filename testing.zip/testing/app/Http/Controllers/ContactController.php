<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contact;
use App\Models\Country;

class ContactController extends Controller
{
    public function index()
    {
     $countries=Country::all();
  
        return view('index',compact('countries'));
    }

    public function submiting(Request $request)
    {
        $data= $request->input();
       

        $imgname='';
        if($request->hasFile('image'))
    {
        $file=$request->file('image');
        $filename=$file->getClientOriginalName();
        $fileext=$file->getClientOriginalExtension();
        $imgname=uniqid().$filename;
        
        $path=public_path('/img/');
        $file->move($path,$imgname);
    
         
    }
        $contact=new Contact;
        $contact->name=$data['name'];
        $contact->email=$data['email'];
        $contact->mobile=$data['phone'];
        $contact->addres=$data['address'];
        $contact->city=$data['country'];
        $contact->image=$imgname;
        $contact->details=$data['message'];
if($contact->save())
{
    echo "data saved";
    return redirect()->back();
}
  
    }
}
